<?php
require_once ("../vendor/autoload.php");
ini_set('session.gc_maxlifetime', 60);
ini_set('display_errors', 1);
ini_set('error_reporting', -1);
require 'header.php';
?>
<div class="main">
    <div class="header2">
        <div class="frame">
            <a href="https://google.com"><h1>TEETÄ TILAUKSESTA</h1></a>
            <div class="image-desc">
                <p><a href="http://localhost:63342/IlyaJan/app/order/order.php?variant=green&title=Tee%20jasmiinin%20kanssa">Tee jasmiinin kanssa</a><br /></p>
                <p><a href="http://localhost:63342/IlyaJan/app/order/order.php?variant=red&title=Tee%20appelsiininkuorella">Tee appelsiininkuorella</a><br /></p>
                <p><a href="http://localhost:63342/IlyaJan/app/order/order.php?variant=limon&title=Tee%20appelsiininkuorella">Tee ruusun terälehdillä</a><br /></p>
                <p><a href="http://localhost:63342/IlyaJan/app/order/order.php?variant=last&title=Tee%20mausteinen">Tee mausteinen</a><br /></p>
            </div>
        </div>
        <ul>
            <li><a href="google.com"><span class="textIntoHead">piristää</span></a></li>
            <li><a href="google.com"><span class="textIntoHead">eväste</span></a></li>
            <li><a href="google.com"><span class="textIntoHead">toinen</span></a></li>
        </ul>


        <div style="position: absolute; right: 1cm; top: 0.9cm">
            <a href="../app/order/payment.php">
                <img src="../resources/symka.png" alt="HTML tutorial" style="width:62px;height: 62px;">
            </a>
            <?php
            if(isset($_SESSION['cart'])){
                if($_SESSION['cart'] > 0) echo "<div id='mark'></div>";
                echo "<h1>" . var_dump($_SESSION['cart']) . "</h1>";
            }
            ?>
        </div>
    </div>

            <?php
            if (isset($_SESSION['user_id'])){
                //echo "<h1>УРААААААААА авторизация</h1>";
            }
            ?>
            <?php
                //echo "<a style='text-decoration: none; color: white;' href='/IlyaJan/app/admin/viewOfUsers.php'>Ссылка</a>";
            ?>
            <div class='position-left-main'>
                <div class='subtitle'>
                    <p>
                        Valitsemalla teetä teet oikean<br />
                        valinnan. Meillä on vain<br />
                        parhaat lajikkeet.<br />
                    </p>
                </div>
            </div>


    <?php /*
    <div class="hystmodal" id="myModal">
        <div class="hystmodal__wrap">
            <div class="hystmodal__window" role="dialog" aria-modal="true">
                <button data-hystclose class="hystmodal__close">Close</button>
                <h1>Заголовок модального окна</h1>
                <p>Текст модального окна ...</p>
                <img src="img/photo.jpg" alt="" width="400" />
                <p>Ещё текст модального окна ...</p>
            </div>
        </div>
    </div>";
 */
    ?>
<?php
require_once 'footer.html';
?>