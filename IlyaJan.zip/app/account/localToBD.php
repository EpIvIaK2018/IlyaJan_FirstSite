<?php
session_start();
require $_SERVER['DOCUMENT_ROOT'] . "/app/Connect.php";
ini_set('display_errors', 1);
ini_set('error_reporting', 1);

if (empty($_POST['data'])) {

} else {
    $file = 'D:\people.txt';
    $current = $_POST['data'];
    $userId = $_SESSION['user_id'];
    $connect = App\Connect::getInstance();
    $list =  json_decode($current, true);
    foreach ($list as $key => $val){
        $stmt = $connect::getLink()->prepare("SELECT count FROM cart_items WHERE (`id_Customer` = :id_Customer AND `product` = :product)");
        $stmt->bindValue(':id_Customer', $userId, PDO::PARAM_INT);
        $stmt->bindValue(':product', $key);
        $stmt->execute();
        while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) {
            foreach ($result as $v){
                if($v > 0){
                    $newVal = $v + $val;
                    $stmt = $connect::getLink()->prepare("UPDATE cart_items SET count = '$newVal' WHERE (`id_Customer` = :id_Customer AND `product` = :product)");
                    $stmt->bindValue(':id_Customer', $userId, PDO::PARAM_INT);
                    $stmt->bindValue(':product', $key);
                    $stmt->execute();
                }
            }
        }
        var_dump($list);
    }
}
