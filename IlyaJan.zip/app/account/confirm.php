<?php

use App\Connect;

ini_set('display_errors', 1);
ini_set('error_reporting', -1);
require "../Connect.php";
if(!empty($_POST)){
    $log = $_POST['loginforReg'];
    $pass = password_hash($_POST['passwordforReg'], PASSWORD_ARGON2I );
    $ava = "../../resources/person.png";
    $email = $_POST['emailforReg'];
    $ip = $_POST['ip'];
    $publicName = strtoupper($log);

    $sql = "INSERT INTO users (id_Customer, login, password, avatar, email, publicName, ip) 
    VALUES (2, '$log', '$pass', '$ava', '$email', '$publicName', '$ip')";

    $stmt = Connect::getInstance()->getLink()->prepare($sql);
    $stmt->execute();


    header('Location: ../admin/viewOfUsers.php');
}