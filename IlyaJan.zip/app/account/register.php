<?php
require $_SERVER['DOCUMENT_ROOT'] . '/public/header.php';
$url = $_SERVER['DOCUMENT_ROOT'] . "../public/index.php";
if(!empty($_SESSION['login'])){
    echo header("Location:". $url);
    echo "<h1>" . 'Вы уже зарегистрированы, Вы будете перенаправлены' . "</h1>";
}
echo<<<REG
    <!doctype html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport"
              content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Document</title>
        <link rel="stylesheet" type="text/css" href="/app/style.css">
        <script>
            function validate(){
                let patternMail = /^[a-zA-Z0-9_.-]+@([a-z0-9-]+\.)+[a-z]{2,6}$/i;                                            
                let pattertPass = /(?=.*[0-9])(?=.*[a-z])[0-9a-zA-Z!@#$%^&*]{6,}/g
                let login = document.forms['validForm']['loginforReg'].value;
                let email = document.forms["validForm"]["emailforReg"].value;
                let pass = document.forms["validForm"]["passwordforReg"].value;
                let passRepeat = document.forms["validForm"]["passwordSubmit"].value;
                if(!patternMail.test(email)){
                    alert("Некорректный Email");
                    return false;
                }
                if(pass.length < 6){
                    alert("Пароль не менее 6 символов");
                    return false;
                }
                if(!pattertPass.test(pass)){
                    alert("Пароль с использованием цифр и латиницы");
                    return false;
                }
                if(pass != passRepeat){
                    alert("Неверное подтверждение пароля");
                    return false;
                }
                if(login.length < 3){
                    alert("Слишком короткий логин, не менее 3 символов")
                    return false;
                }
                return true;
            }
        </script>    
    </head>
    <body>
    <div class="reg">
        <h1 style="color: cornflowerblue; margin-bottom: 3vh">Create Account</h1>
        <form method="post" action="confirm.php" name="validForm" class='formWithValidation' onsubmit="return validate()">
            <div>
                <label>Логин:<input style="font-family: Calibri; font-size: 25px; width: 18vw" type="text" name="loginforReg" required></label>
            </div>
            <div>
                <label>Пароль:<input style="font-family: Calibri; font-size: 25px; width: 18vw" type="password" name="passwordforReg" id="pass" required></label>
            </div>
    
            <div>
                <label>Подтвердите пароль:<input style="font-family: Calibri; font-size: 25px; width: 18vw" type="password" name="passwordSubmit" id="passRepeat" required></label>
            </div>
    
            <div>
                <label>Почта:<input style="font-family: Calibri; font-size: 25px; width: 18vw" type="text" name="emailforReg" id="email" required></label>
            </div>
            <input type="hidden" name="ip" value=<?php echo getIp() ?>
            <input type="submit" name="ok" class="validateBtn">
        </form>
    </div>
    </body>
    </html>
REG;
function getIp(): string
{
    $value = '';
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $value = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $value = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
        $value = $_SERVER['REMOTE_ADDR'];
    }
    return $value;
}
?>

<?=require_once  $_SERVER['DOCUMENT_ROOT'] . '/public/footer.html';?>
