<?php
namespace App;
require __DIR__ . '/../vendor/autoload.php';
$connect = Connect::getInstance();

