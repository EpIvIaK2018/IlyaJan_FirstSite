<?php
namespace App\order;
require 'product.php';
class greenTea extends product
{
    public function __construct($weight)
    {
        $this->priceFor50 = 1.5;
        $this->weight = (double)$weight;
    }
}