<?php
require $_SERVER['DOCUMENT_ROOT'] . "/app/getConnect.php";
use App\Connect;

session_start();
ini_set('display_errors', 1);
ini_set('error_reporting', 1);
//echo $_SESSION['login'];
if(empty($_SESSION['login'])){
    echo " 
        <h2>Небходимо войти для оформления заказа</h2>
        <div><a href='/app/account/login.php'>Войти</a></div>
    ";
}else{
    $stmt = Connect::getLink()->prepare('SELECT * FROM cart_items WHERE id_Customer = ?');
    $stmt->bindParam(1, $_SESSION['user_id']);
    $stmt->execute();
    $output = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($output as $v){
        var_dump($v);
    }
}

//echo "<script>alert(localStorage.getItem('listOfTovars'))</script>";
//echo "<script>alert(localStorage.getItem('listOfTovars'))</script>";
//echo $_SESSION["listT"];
?>

<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html" charset="UTF-8">
    <title>Главная</title>
    <link rel="stylesheet" type="text/css" href="/app/style.css">
    <style>
        a{
            font-size: 50px;
            color: darkgreen;
        }
    </style>
</head>
<body>

</body>