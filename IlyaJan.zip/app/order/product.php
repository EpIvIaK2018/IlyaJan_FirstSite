<?php
namespace App\order;

abstract class product
{
    protected float $priceFor50;
    protected float $weight;
}