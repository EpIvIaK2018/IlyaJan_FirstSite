<?php
namespace App\order;
require 'product.php';

class limonTea extends product
{
    function __construct(int $weight)
    {
        $this->priceFor50 = 2.1;
        $this->weight = $weight;
    }
}
