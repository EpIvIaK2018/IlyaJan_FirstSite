<?php
namespace App\order;
require 'product.php';

class lastTea extends product
{
    function __construct(int $weight)
    {
        $this->priceFor50 = 3.5;
        $this->weight = $weight;
    }
}
