<?php
namespace App\order;
require 'product.php';
class redTea extends product
{
    function __construct(int $weight)
    {
        $this->priceFor50 = 2.5;
        $this->weight = $weight;
    }
}
