<?php
namespace App;
require ("../../vendor/autoload.php");
ini_set('display_errors', 1);
ini_set('error_reporting', -1);
require '../../public/header.php';

if(isset($_SESSION['login']))echo $_SESSION['login'];

if(isset($_GET['variant']) && isset($_GET['title'])){
    $url = '';
    switch ($_GET['variant']){
        case 'green':
            $url = '/resources/orderGreen.jpeg';
            break;
        case 'red':
            $url = '/resources/orderRed.jpg';
            break;
        case 'limon':
            $url = '/resources/orange.jpg';
            break;
        case 'last':
            $url = '/resources/last.jpeg';
            break;
    }
} else{
    header("Location: ../../public/index.php");
}
if (isset($_COOKIE['value'])){
    /*
    $val = $_COOKIE['value'];
    productsSummary::addProduct(new greenTea($val));
    var_dump(productsSummary::getSumALl());
    unset($_COOKIE['value']);
    */
    //echo "<script>document.cookie = value=; path='', expires=-1;</script>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Order</title>

    <style>
        .global{
            background: url(<?= $url?>);
            background-size: cover;
            z-index: 1;
            position: fixed;
            min-height: 100%;
            min-width: 100%;
            height: 100%;
            width: 100%;
        }
        .position-left-main{
            min-width: 98%;
            height: 5cm;
            bottom: 2cm;
        }

        .subtitle{
            left: 0.2cm;
            position: absolute;
            line-height: 1cm;
            width: 96%;
            height: 3cm;
            bottom: 3%;
        }

        .subtitle p{
            top: 0.2cm;
            font-size: 25px;
            letter-spacing: 8px;
        }

        .decor{
            left: 1.8cm;
            position: absolute;
            height: 250px;
            width: 250px;
            border: solid 45px #2ab732;
            border-radius: 50%;
            z-index: 3;
        }

        .intoDecor{
            height: 250px;
            width: 250px;
            position: absolute;
            object-fit: cover;
            left: 2.5cm;
            top: 6.2cm;
        }
    </style>
    <script>

    </script>

</head>

<body>
<div class="main">
    <div class="header2">
        <div class="frame">
            <h1><?=$_GET['title']?></h1>
        </div>
        <ul>
            <li><a href="google.com"><span class="textIntoHead">piristää</span></a></li>
            <li><a href="google.com"><span class="textIntoHead">eväste</span></a></li>
            <li><a href="google.com"><span class="textIntoHead">toinen</span></a></li>
        </ul>


        <div style="position: absolute; right: 1cm; top: 0.9cm">
            <a href="payment.php">
                <img src="../../resources/symka.png" alt="HTML tutorial" style="width:62px;height: 62px;">
            </a>
            <?php
            if(isset($_SESSION['cart'])){
                if($_SESSION['cart'] > 0) echo "<div id='mark'></div>";
            }
            ?>
        </div>
    </div>
        <div class="order">
            <span>Pakkaus</span>
            <button><a href="http://localhost:63342/IlyaJan/app/order/toCart.php?id=50&variant=<?= $_GET['variant'] ?? ""?>&title=<?=$_GET['title'] ?? ""?>">50gr.</a></button><br>
            <button><a href="http://localhost:63342/IlyaJan/app/order/toCart.php?id=100&variant=<?= $_GET['variant'] ?? ""?>&title=<?=$_GET['title'] ?? ""?>">100gr.&nbsp;&nbsp;&nbsp;</a></button>
            <button><a href="http://localhost:63342/IlyaJan/app/order/toCart.php?id=150&variant=<?= $_GET['variant'] ?? ""?>&title=<?=$_GET['title'] ?? ""?>">150g.</a><br /></button>
        </div>

        <div class="subtitle">
            <p>
                Ainutlaatuinen elävä orgaaninen tee, jolla on vahva käyminen aurinkoisten i säntien puhtaista<br />
                istutuksista. Uskomattoman maukasta ja terveellistä. Koottu ja valmistettu käsin tänä keväänä.
            </p>
        </div>
    <?php
    require_once '../../public/footer.html';
    ?>
</body>
</html>
