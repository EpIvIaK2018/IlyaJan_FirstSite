<?php
    return [
        '127.0.0.1',
        'ilyajan',
        'root',
        'root'
    ];